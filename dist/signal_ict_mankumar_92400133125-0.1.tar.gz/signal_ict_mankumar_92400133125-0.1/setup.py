from setuptools import setup, find_packages

setup(
    name="signal_ICT_mankumar_92400133125",
    version="0.1",
    packages=find_packages(),
    install_requires=["numpy", "matplotlib"],
    author="Your Name",
    description="Signal processing package for ICT lab",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
)
